from opendss.la.load_allocation import run_load_allocation
